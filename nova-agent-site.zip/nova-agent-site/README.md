# Nova Agent site

Single-file landing page (plain HTML/CSS/JS + three.js 0.160.0 from unpkg). No build step.

## Files
| Path | What it is |
|---|---|
| `index.html` | The whole website |
| `.github/workflows/pages.yml` | Deploys the site to GitHub Pages on every push to `main` |
| `bursar/` | Notes and a script for forking and hosting the Bursar console |
| `.nojekyll`, `.gitignore` | Housekeeping |

## Publish on GitHub Pages
1. Create a new GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Repo **Settings → Pages → Source: GitHub Actions**.
3. Push to `main`. The site appears at `https://<you>.github.io/<repo>/`.

## Run locally
Do not open `index.html` as a `file://` link; the three.js module imports need http.
```
npx serve .
```

## Connect Bursar
The "Launch Nova" button in `index.html` has `id="launch"`. After you host the Bursar console
(see `bursar/README.md`), set its `href` to that URL, e.g. `https://app.yoursite.com`.

## Notes
- All brand names, people and reviews on the page are fictional.
- Fonts load from Google Fonts. Embed them as base64 if you need the page fully offline.
- No license file is included; add one if you want to open-source the site.
