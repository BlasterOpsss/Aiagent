#!/usr/bin/env bash
set -euo pipefail
FORK_URL="${1:?Usage: ./setup.sh https://github.com/<you>/bursar.git}"
git clone "$FORK_URL" bursar-fork
cd bursar-fork
corepack enable
pnpm install --frozen-lockfile
echo "Starting the console on http://localhost:${PORT:-4310}"
pnpm --filter @bursar/web dev
