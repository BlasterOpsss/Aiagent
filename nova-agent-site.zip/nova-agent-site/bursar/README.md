# Hosting the Bursar console

This folder does not contain Bursar's code. Fork the original repo on GitHub:
https://github.com/bursar-world/bursar (MIT license; keep LICENSE and NOTICE in your fork).

## Steps
1. On GitHub, open the repo above and tap **Fork**.
2. Run `./setup.sh https://github.com/<you>/bursar.git` (Node 22+ and corepack needed).
   It clones your fork into `bursar-fork/`, installs, and starts the console on http://localhost:4310.
3. Rebrand under `apps/web` in your fork.
4. Deploy `apps/web` to a host that runs Node (Vercel, Railway, Render, Fly.io or a VPS).
   Check `apps/web/README.md` and `apps/web/package.json` in your fork for the exact build and start commands.
   The host needs the full monorepo checkout, installed with `pnpm install --frozen-lockfile`.
5. Put it on a subdomain such as `app.yoursite.com`, then set the "Launch Nova" button in `../index.html` to that URL.

## Warnings
- The console talks to live Robinhood Chain mainnet (chain 4663) contracts with real funds.
  The current contract set is a development deployment. Read SECURITY.md in the Bursar repo first and test with tiny amounts.
- Charging agents (the provider side) needs the facilitator and sidecar running on a server with Postgres. A static site cannot do this.
- Never commit agent keys or relayer keys. Keep them in environment variables.
